function GetOHMDD(AM, AD, Y, trainingMatrix)
    
    nm = size(Y, 1);
    nd = size(Y, 2);

    [KD, KM] = GaussianKernel(trainingMatrix', 1, 1);
    
    KM(logical(eye(size(KM)))) = 0;
    KD(logical(eye(size(KD)))) = 0;
    AM(size(AM, 2) + 1) = {KM};
    AD(size(AD, 2) + 1) = {KD};
        
    F = MultiViewPrediction(AM, AD, trainingMatrix);
    
    % output the final score
    filename = 'output/ohmdd.txt';
    fp = fopen(filename, 'w');
    fprintf(fp, '%s\t%s\n', 'label', 'score');
    for i = 1:nm
        for j = 1:nd
            if trainingMatrix(i, j) ~= 1
                fprintf(fp, '%d\t%e\n', Y(i, j), F(i, j));
            end
        end
    end
    fclose(fp);
    
end