clc;              
clear;            % clear all workspace variables
close all;        % close all windows
  
currentFolder = pwd;              
addpath(genpath(currentFolder));

load('datasets/miR_sim.mat');
load('datasets/disease_sim.mat');
load('datasets/miR_disease_matrix.mat');

