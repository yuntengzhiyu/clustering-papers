function GetLODOCV(AM, AD, Y)
% Y is the input miR-disease association matrix;

	nm = size(Y, 1); 
    nd = size(Y, 2);
    
    for curIndex = 1:nd   
        
        fprintf('Current disease : %d\n', curIndex);
        
        Y_temp = Y;
        Y_temp(:, curIndex) = 0;
        
        % compute the Gaussian Interaction Profile
        [KD, KM] = GaussianKernel(Y_temp', 1, 1);
        
        KM(logical(eye(size(KM)))) = 0;
        KD(logical(eye(size(KD)))) = 0;
        AM(size(AM, 2) + 1) = {KM};
        AD(size(AD, 2) + 1) = {KD};
        
        F = MultiViewPrediction(AM, AD, Y_temp);
        
        % output the final score
        filename = sprintf('output/lodocv/%d.txt', curIndex);
        fp = fopen(filename, 'w');
        fprintf(fp, '%s\t%s\n', 'label', 'score');
        for i = 1:nm
            fprintf(fp, '%d\t%e\n', Y(i, curIndex), F(i, curIndex));
        end
        fclose(fp);
    end

end